/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BOLA;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


/**
 *
 * @author WIN -8
 */
public class Bola {
    public static void main(String[]args)throws IOException {
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        BOLA.proses BOLA = new BOLA.proses ();
        try 
        {
            System.out.println("Masukkan Nilai Jarijari :");
            String s = dataIn.readLine();
            BOLA.setJari(Integer.parseInt (s));
           
            
            System.out.println("Jarijari BOLA="+BOLA.getJari());
            
            System.out.println("Volume BOLA="+BOLA.hitungVolume ());
        }
            catch (IOException e)        
        {
          System.out.println("Data yang di input salah");
        }
        
    }
    
}
        
        
    
    

