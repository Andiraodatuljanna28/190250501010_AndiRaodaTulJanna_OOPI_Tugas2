/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KERUCUT;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author WIN -8
 */
public class Kerucut {
    public static void main(String[]args)throws IOException{
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        KERUCUT.proses KERUCUT = new KERUCUT.proses ();
        try
        {
            System.out.println("inputkan Nilai Jarijari :");
            String r = dataIn.readLine();
            KERUCUT.setJari(Integer.parseInt (r));
            
            System.out.println("inputkan Nilai Tinggi :");
            String t = dataIn.readLine ();
            KERUCUT.setTinggi(Integer.parseInt (t));
            
            System.out.println("Jarijari KERUCUT="+KERUCUT.getJari());
            System.out.println("Tinggi KERUCUT="+KERUCUT.getTinggi ());
            System.out.println("Volume KERUCUT="+KERUCUT.hitungVolume ());
             
        }
        catch (IOException e)
        {
            System.out.println("Data yang di input salah");
        }
     }
    }

       
